import './globals.css'
import { ReactNode } from 'react'
export const metadata={title:'Physics Adda | Learn Physics. Crack WBJEE.',description:'Physics Adda — concept-first Physics learning for WBJEE and Classes 11–12.'}
export default function RootLayout({children}:{children:ReactNode}){return <html lang="en"><body>{children}</body></html>}
