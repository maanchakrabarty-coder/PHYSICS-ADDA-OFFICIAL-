'use client'

import { FormEvent, useEffect, useState } from 'react'
import Link from 'next/link'
import { supabase } from '../../lib/supabase'

const db = supabase()

type Course = { id:number; title:string }

export default function Admin(){
  const [loading,setLoading]=useState(true)
  const [allowed,setAllowed]=useState(false)
  const [courses,setCourses]=useState<Course[]>([])
  const [message,setMessage]=useState('')

  async function load(){
    const {data:{user}}=await db.auth.getUser()
    if(!user){ setLoading(false); return }
    const {data:profile}=await db.from('profiles').select('role').eq('id',user.id).single()
    if(profile?.role==='admin'){
      setAllowed(true)
      const {data}=await db.from('courses').select('id,title').order('created_at',{ascending:false})
      setCourses(data||[])
    }
    setLoading(false)
  }
  useEffect(()=>{load()},[])

  async function addCourse(e:FormEvent<HTMLFormElement>){
    e.preventDefault(); setMessage('')
    const f=new FormData(e.currentTarget)
    const title=String(f.get('title')||''); const slug=String(f.get('slug')||''); const description=String(f.get('description')||''); const price=Number(f.get('price')||0)
    const {error}=await db.from('courses').insert({title,slug,description,price})
    setMessage(error?error.message:'Course published successfully.')
    if(!error){e.currentTarget.reset();load()}
  }

  async function addLesson(e:FormEvent<HTMLFormElement>){
    e.preventDefault(); setMessage('')
    const f=new FormData(e.currentTarget)
    const {error}=await db.from('lessons').insert({course_id:Number(f.get('course_id')),title:String(f.get('title')),video_url:String(f.get('video_url')||''),notes_url:String(f.get('notes_url')||''),sort_order:Number(f.get('sort_order')||0)})
    setMessage(error?error.message:'Lecture published successfully.')
    if(!error)e.currentTarget.reset()
  }

  async function addNote(e:FormEvent<HTMLFormElement>){
    e.preventDefault(); setMessage('')
    const f=new FormData(e.currentTarget); const file=f.get('file') as File
    let file_url=String(f.get('file_url')||'')
    if(file && file.size){
      const path=`notes/${crypto.randomUUID()}-${file.name}`
      const upload=await db.storage.from('notes').upload(path,file,{upsert:false})
      if(upload.error){setMessage(upload.error.message);return}
      const pub=db.storage.from('notes').getPublicUrl(path); file_url=pub.data.publicUrl
    }
    const {error}=await db.from('notes').insert({title:String(f.get('title')),category:String(f.get('category')),description:String(f.get('description')||''),file_url})
    setMessage(error?error.message:'Note published successfully.')
    if(!error)e.currentTarget.reset()
  }

  async function addTest(e:FormEvent<HTMLFormElement>){
    e.preventDefault(); setMessage('')
    const f=new FormData(e.currentTarget)
    const {data,error}=await db.from('tests').insert({title:String(f.get('title')),course_id:Number(f.get('course_id')),duration_minutes:Number(f.get('duration_minutes')||30)}).select('id').single()
    setMessage(error?error.message:`Test created. Test ID: ${data?.id}`)
    if(!error)e.currentTarget.reset()
  }

  async function signOut(){await db.auth.signOut();location.href='/login'}

  if(loading)return <main className="center"><div className="card">Loading admin panel…</div></main>
  if(!allowed)return <main className="center"><div className="card"><h2>Admin access required</h2><p className="muted">Sign in with an account whose profile role is <b>admin</b>.</p><Link className="btn" href="/login">Go to Login</Link></div></main>

  return <>
    <nav className="nav"><div className="brand">PHYSICS <span>ADDA</span></div><div className="navlinks"><Link href="/">Home</Link><Link href="/dashboard">Dashboard</Link><button className="btn ghost" onClick={signOut}>Sign out</button></div></nav>
    <section><div className="eyebrow">ADMIN PANEL</div><h1>Publish & Manage Content</h1><p className="muted">Create courses, lectures, notes and tests from one dashboard.</p>{message&&<div className="notice">{message}</div>}
      <div className="admin-grid">
        <form className="card form" onSubmit={addCourse}><h3>➕ Create Course</h3><input name="title" required placeholder="Course title"/><input name="slug" required placeholder="slug e.g. attempt-bangla"/><textarea name="description" placeholder="Description"/><input name="price" type="number" min="0" placeholder="Price (₹)"/><button className="btn">Publish Course</button></form>
        <form className="card form" onSubmit={addLesson}><h3>🎥 Add Lecture</h3><select name="course_id" required><option value="">Select course</option>{courses.map(c=><option key={c.id} value={c.id}>{c.title}</option>)}</select><input name="title" required placeholder="Lecture title"/><input name="video_url" placeholder="YouTube / video URL"/><input name="notes_url" placeholder="Notes URL"/><input name="sort_order" type="number" placeholder="Order"/><button className="btn">Publish Lecture</button></form>
        <form className="card form" onSubmit={addNote}><h3>📚 Upload Note / DPP</h3><input name="title" required placeholder="Note title"/><input name="category" placeholder="Physics / WBJEE / DPP"/><textarea name="description" placeholder="Short description"/><input name="file" type="file" accept="application/pdf"/><input name="file_url" placeholder="Or paste a public PDF URL"/><button className="btn">Publish Note</button></form>
        <form className="card form" onSubmit={addTest}><h3>📝 Create Test</h3><select name="course_id" required><option value="">Select course</option>{courses.map(c=><option key={c.id} value={c.id}>{c.title}</option>)}</select><input name="title" required placeholder="Test title"/><input name="duration_minutes" type="number" min="1" defaultValue="30"/><button className="btn">Create Test</button></form>
      </div>
    </section>
  </>
}
