# Physics Adda — Full-stack starter

Next.js + Supabase starter for the Physics Adda EdTech platform.

## 1. Install
`npm install`

## 2. Environment
Copy `.env.example` to `.env.local` and add your Supabase URL and anon key.

## 3. Supabase
Run `supabase/schema.sql` in Supabase SQL Editor. Create a Storage bucket named **notes** and make it public for this starter's PDF links.

Create a user through the app/login page. Then in Supabase SQL Editor promote that account to admin:
`update public.profiles set role='admin' where id='YOUR_AUTH_USER_UUID';`

## 4. Run
`npm run dev`

Open `/admin` for the admin CMS. Admin can publish courses, lectures, PDF notes/DPPs and tests.

### Important
This starter uses Supabase's browser client. For production, add stricter storage policies, server-side authorization, payment verification and private video/PDF delivery before accepting paid enrollments.
